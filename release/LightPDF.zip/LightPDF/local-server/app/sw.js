const CACHE = 'lightpdf-3e05511569d1';
const ASSETS = ["./","./assets/__vite-browser-external-CobD5bNO.js","./assets/compose-CnyDZbFp.js","./assets/dom-CI2ZLxX5.js","./assets/images-G47S-I81.js","./assets/index-B7UjVz72.css","./assets/index-CXWQ6CiN.js","./assets/jbig2-BUnLb-NU.wasm","./assets/jszip.min-B_TEw5bb.js","./assets/marks-DYU4dx0E.js","./assets/marks-svg-CI2I5Kjx.js","./assets/marks-svg-DFMgDfR5.js","./assets/model-BfvOqel8.js","./assets/mupdf-DtCSA8mG.js","./assets/mupdf-U76UOPIx.js","./assets/mupdf-wasm-BxyDpI7a.bin","./assets/openjpeg-tw7Aizcv.wasm","./assets/page-editor-C0ANt5dA.js","./assets/pdf-BHx8b9rl.js","./assets/pdf-Bj7RZv_J.js","./assets/pdf-vq2Q2QfL.js","./assets/pdf.worker.min-CjEcRF4W.mjs","./assets/pdfjs-D7Ky2hdD.js","./assets/pdfjs-DilT66_I.js","./assets/preload-helper-CRzLMJPS.js","./assets/properties-BI7A-zvg.js","./assets/raster-R0VhtxEd.js","./assets/redact-syPDXffZ.js","./assets/rolldown-runtime-pP25SEvz.js","./favicon.svg","./icon-192.png","./icon-512.png","./manifest.webmanifest"];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith('lightpdf-') && key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    // Network first for the page itself, so updates arrive when online.
    event.respondWith(fetch(request).catch(() => caches.match('./', { ignoreSearch: true, ignoreVary: true })));
    return;
  }
  // Built files never change under the same name, so headers such as Vary: Origin don't matter.
  event.respondWith(caches.match(request, { ignoreVary: true }).then((cached) => cached || fetch(request)));
});
