const CACHE = 'lightpdf-123d1a2ca03a';
const ASSETS = ["./","./assets/compose-85IYlfuG.js","./assets/index-CeUONUNz.js","./assets/index-XqwnVZXR.css","./assets/jbig2-BUnLb-NU.wasm","./assets/jszip.min-DPp8CkPK.js","./assets/openjpeg-tw7Aizcv.wasm","./assets/pdf-BHx8b9rl.js","./assets/pdf-CKMSdNyg.js","./assets/pdf.worker.min-CjEcRF4W.mjs","./assets/raster-Bs_PFU71.js","./favicon.svg","./icon-192.png","./icon-512.png","./manifest.webmanifest"];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith('lightpdf-') && key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    // Network first for the page itself, so updates arrive when online.
    event.respondWith(fetch(request).catch(() => caches.match('./', { ignoreSearch: true, ignoreVary: true })));
    return;
  }
  // Built files never change under the same name, so headers such as Vary: Origin don't matter.
  event.respondWith(caches.match(request, { ignoreVary: true }).then((cached) => cached || fetch(request)));
});
