const CACHE = 'lightpdf-fd087b1facfb';
const ASSETS = ["./","./assets/compose-BcIFVk1i.js","./assets/index-BYiGX8Sd.js","./assets/index-D6pS7yxh.css","./assets/jbig2-BUnLb-NU.wasm","./assets/jszip.min-CKt90vNl.js","./assets/openjpeg-tw7Aizcv.wasm","./assets/pdf-B4eA1mdp.js","./assets/pdf-BHx8b9rl.js","./assets/pdf.worker.min-CjEcRF4W.mjs","./assets/raster-CG-PvDFE.js","./favicon.svg","./icon-192.png","./icon-512.png","./manifest.webmanifest"];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith('lightpdf-') && key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    // Network first for the page itself, so updates arrive when online.
    event.respondWith(fetch(request).catch(() => caches.match('./', { ignoreSearch: true, ignoreVary: true })));
    return;
  }
  // Built files never change under the same name, so headers such as Vary: Origin don't matter.
  event.respondWith(caches.match(request, { ignoreVary: true }).then((cached) => cached || fetch(request)));
});
